# NEXUS (single-file build)
Open nexus.html in a modern browser (needs internet for CDN scripts: mathjs 12.4.1, GSAP 3.12.5, three r128).
Features: scientific calculator (mathjs, whitelist-validated), graphing, equation solver, local history,
GSAP intro (skippable/disable-able), reduced-motion support, light/dark themes, shader-based 3D background
with per-tab scene states, pointer parallax/repulsion, pulse on calculation, visibility pause, delta-time animation.
NOT included: Express/Prisma/PostgreSQL/auth/tests/lockfile (never built; no project of that kind existed).
